

local tr = aegisub.gettext
script_name = tr("获取up主视频基本数据")
script_description = tr("获取up主视频基本数据")
script_author = "拉姆0v0"
script_version = "v0.9"

include("karaskel.lua")
local util = require 'aegisub.util'
local json = require'json'
local request = require("luajit-request")
local ffi = require"ffi"
local utf8 = require"utf8"

-- 序列化和反序列化方法
function serialize(obj)
    local lua = ""
    local t = type(obj)
    if t == "number" then
        lua = lua .. obj
    elseif t == "boolean" then
        lua = lua .. tostring(obj)
    elseif t == "string" then
        lua = lua .. string.format("%q", obj)
    elseif t == "table" then
        lua = lua .. "{\n"
    for k, v in pairs(obj) do
        lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
    end
    local metatable = getmetatable(obj)
        if metatable ~= nil and type(metatable.__index) == "table" then
        for k, v in pairs(metatable.__index) do
            lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
        end
    end
        lua = lua .. "}"
    elseif t == "nil" then
        return nil
    else
        error("can not serialize a " .. t .. " type.")
    end
    return lua
end

function unserialize(lua)
    local t = type(lua)
    if t == "nil" or lua == "" then
        return nil
    elseif t == "number" or t == "string" or t == "boolean" then
        lua = tostring(lua)
    else
        error("can not unserialize a " .. t .. " type.")
    end
    lua = "return " .. lua
    local func = loadstring(lua)
    if func == nil then
        return nil
    end
    return func()
end

--合并两个table
function MergeTables(...)
    local tabs = {...}
    if not tabs then
        return {}
    end
    local origin = tabs[1]
    for i = 2,#tabs do
        if origin then
            if tabs[i] then
                for k,v in pairs(tabs[i]) do
                    table.insert(origin,v)
                end
            end
        else
            origin = tabs[i]
        end
    end
    return origin
end


function get_videoinfo(bvid)
	local url = "http://api.bilibili.com/x/web-interface/view?bvid="..bvid
	local result, err, message = request.send(url)
	if (not result) then aegisub.debug.out(err, message) end
	return result.body
end

function get_video_desc(bvid)
	local url = "http://api.bilibili.com/x/web-interface/archive/desc?bvid="..bvid
    local result, err, message = request.send(url)
	if (not result) then aegisub.debug.out(err, message) end
	return result.body
end

function get_userinfo(mid,pn,ps)
	local url = "http://api.bilibili.com/x/space/arc/search?mid="..mid.."&pn="..pn.."&ps="..ps
	local result, err, message = request.send(url)
	if (not result) then aegisub.debug.out(err, message) end
	return result.body
end

-- 输入年 得到天数
function year_to_days(year)
    return ((year%4==0 and year%100 ~= 0) or year%400==0) and 366 or 365
end

-- 计算日期差值
function time_subtraction_by_day(t1,t2)
    local day1 = tonumber(os.date("%j",t1))
    local day2 = tonumber(os.date("%j",t2))
    local year1 = tonumber(os.date("%Y",t1))
    local year2 = tonumber(os.date("%Y",t2))
    if year1 == year2 then
        return day2-day1
    elseif year2 > year1 then
        local out_days = day2-day1
        for i = 1,year2-year1 do
            out_days = out_days + year_to_days(year1 + i - 1)
        end
        return out_days
    end
end

-- 获取稿件数
function get_videonum(uid)
    return json.decode(get_userinfo(uid,1,1)).data.page.count
end

-- 获取完整的简介
function get_full_desc(videos_info_table)
    aegisub.progress.task("获取完整简介")
    for k,v in pairs(videos_info_table) do
        local body = json.decode(get_video_desc(v.bvid))
        if body.code == 0 then
            aegisub.debug.out("【"..v.bvid.."】简介获取成功\n")
            videos_info_table[k].description = body.data
        else
            aegisub.debug.out(body.message.."\n")
        end
        aegisub.progress.set(k/#videos_info_table*100)
    end
    aegisub.debug.out("加载完成\n")
end

-- 获取视频信息表
function get_videos_info(uid)
    local video_num = get_videonum(uid)
    local page_sim = 100
    local page_num = math.ceil(video_num/page_sim)
    local videos_info_table = {}
    aegisub.progress.task("获取视频列表中")
    for i = 1, page_num do
        local vtbl = json.decode(get_userinfo(uid,i,100)).data.list.vlist
        videos_info_table = MergeTables(videos_info_table,vtbl)
        aegisub.progress.set(i/page_num*100)
    end
    return videos_info_table
end

-- 时间格式转换
function get_time(time)
    local time_tbl = {}
    local t = 0
    for word in string.gmatch(time, "%d+") do 
        table.insert(time_tbl,word)
    end
    if #time_tbl==3 then
        t = time_tbl[3]*1000 + time_tbl[2]*1000*60 + time_tbl[1]*1000*60*60
    elseif #time_tbl==2 then
        t = time_tbl[2]*1000 + time_tbl[1]*1000*60
    else
        t = time_tbl[1]*1000
    end
    return t
end





local line_table = {
    ["layer"]=0,
    ["margin_b"]=31,
    ["class"]="dialogue",
    ["extra"]={"撒旦发射点发撒地方是"
    },
    ["margin_t"]=31,
    ["margin_l"]=20,
    ["style"]="【用户视频数据表】",
    ["actor"]="【标题】",
    ["start_time"]=0,
    ["raw"]="Comment: 0,0:00:00.00,0:00:05.00,【用户视频数据表】,【标题】,20,12,31,1231233123,【结束时间=视频时长】【说话人=标题】【特效=播放量】【左=年】【右=月】【垂直边距=日】【文本=简介】",
    ["section"]="[Events]",
    ["text"]="【结束时间=视频时长】【说话人=标题】【特效=播放量】【左=年】【右=月】【垂直边距=日】【文本=简介】",
    ["margin_r"]=12,
    ["comment"]=true,
    ["effect"]="【播放量】",
    ["end_time"]=5000,
}

-- local pre_uid = "474837258"
local pre_uid = "349991143" -- mea组

dialog_config1=
{
    [1]={class="label",x=0,y=0,label="【up主uid】："},
    [2]={class="edit",name="uid",x=1,y=0,width=1,height=1,items={},value=pre_uid},
    [3]={class="label",x=0,y=1,label="【是否获取完整简介】："},
    [4]={class="checkbox",x=1,y=1,name = "isfull", value = false},
    [5]={class="label",x=0,y=2,label="※※※※注意事项※※※※："},
    [6]={class="label",x=1,y=2,label="如果不需要获取完整简介数据，请不要勾选此选择项！"},
}

function get_user_video_info(subs,sel)
    buttons1,results1 = aegisub.dialog.display(dialog_config1,{"OK","Cancel"})
    if buttons1 == "OK" then
        local uid = results1["uid"]
        local isfull = results1["isfull"]
        local videos_info_table = get_videos_info(uid)
        if isfull == true then
            get_full_desc(videos_info_table)
        end
        for i = 1,#subs do
            if subs[i].class == "dialogue" then
                local l = util.copy(line_table)
                for k,v in pairs(videos_info_table) do
                    local Y = os.date("%Y",v.created)
                    local m = os.date("%m",v.created)
                    local d = os.date("%d",v.created)
                    local H = os.date("%H",v.created)
                    local M = os.date("%M",v.created)
                    local S = os.date("%S",v.created)
                    l.actor = v.title
                    l.layer = v.created
                    l.effect = v.play
                    l.raw = "Comment: 0,0:00:00.00,0:00:05.00,【用户视频数据表】,".. v.title..",20,12,31,1231233123,"..v.description..""
                    l.text = v.description
                    l.start_time = get_time(v.length)
                    l.end_time = get_time(v.length)
                    l.margin_l = Y
                    l.margin_r = m
                    l.margin_t = d
                    l.margin_b = d
                    l.comment = false
                    subs.insert(i,l)
                end
                line_table.style = "【"..videos_info_table[1].author.."】"
                subs.insert(i,line_table)
                line_table.style = "【用户视频数据表】"
                break
            end
        end
    end
end

dialog_config2=
{
    [1]={class="label",x=0,y=0,label="【在所有行中中查找】"},
    [2]={class="edit",name="search_text",x=0,y=1,width=1,height=1,value="klq9"},
    [3]={class="label",x=1,y=0,label="【结果】"},
    [4]={class="textbox",name="res",x=1,y=1,width=35,height=20,value=""},
}

function search_on_text(subs,sel)
    local buttons2 ="OK"
    while buttons2 == "OK" do
        buttons2,results2 = aegisub.dialog.display(dialog_config2,{"OK","Exit"})
        if buttons2 == "OK" then
            local search_text = results2["search_text"]
            local arise_times = 0 -- 出现的总次数
            local arise_video_times = 0 -- 出现在投稿的投稿数
            local fY,fm,fd,eY,em,ed,fstamp,estamp -- 首次和最后一次出现的年月日和时间戳
            local isfirst = false -- 判断第一次出现
            local zhaodao = false -- 判断是否找到
            local prev_stamp = -1 -- 上一次出现的时间戳
            local max_interval = -1  -- 最大时间间隔
            local time_data = {} -- 存储出现年月日
            for i = 1,#subs do
                if subs[i].class == "dialogue" then
                    local l = subs[i]
                    local Y = l.margin_l
                    local m = l.margin_r
                    local d = l.margin_t
                    local exist = false
                    for word in string.gmatch(l.text, search_text) do 
                        zhaodao = true
                        arise_times = arise_times+1
                        exist = true
                        if isfirst == false then
                            fY = Y
                            fm = m
                            fd = d
                            fstamp = l.layer
                            eY = Y
                            em = m
                            ed = d
                            estamp = l.layer
                            isfirst = true
                        else
                            eY = Y
                            em = m
                            ed = d
                            estamp = l.layer
                        end
                        -- 存储出现的年月日
                        -- 获取年
                        local month_tbl={}
                        if time_data[l.margin_l] == nil then
                            time_data[l.margin_l] = month_tbl
                        end
            
                        -- 获取月
                        local day_tbl={}
                        if time_data[l.margin_l][l.margin_r] == nil then
                            time_data[l.margin_l][l.margin_r] = day_tbl
                        end
            
                        -- 获取日
                        local day_num=1
                        if time_data[l.margin_l][l.margin_r][l.margin_t] == nil then
                            time_data[l.margin_l][l.margin_r][l.margin_t] = day_num
                        else
                            time_data[l.margin_l][l.margin_r][l.margin_t] = time_data[l.margin_l][l.margin_r][l.margin_t]+1
                        end
                        -- 出现最大时间间隔
                        max_interval = (prev_stamp ~= -1) and math.max(max_interval,time_subtraction_by_day(prev_stamp,l.layer)) or max_interval
                        prev_stamp = l.layer
                    end
                    if exist == true then
                        arise_video_times = arise_video_times + 1
                    end
                end
            end

            local out = ""
            if zhaodao == true then
                out = out.."【查找的字符串】："..search_text.."\n"
                out = out.."【出现的总次数】："..arise_times.."\n"
                out = out.."【出现在投稿中的投稿数】："..arise_video_times.."\n"
                out = out.."【第一次出现时间】："..fY.."年"..fm.."月"..fd.."日\n"
                out = out.."【最后一次出现时间】："..eY.."年"..em.."月"..ed.."日\n"
                out = out.."【时间跨度】："..time_subtraction_by_day(fstamp,estamp).."天\n"
                out = out.."【平均出现天数间隔】：平均"..time_subtraction_by_day(fstamp,estamp)/arise_video_times.."天出现一次\n"
                out = out.."【最长时间间隔】："..max_interval.."天\n"
                out = out.."【按月分析出现时间】\n"
                for k,v in pairs(time_data) do
                    out = out..k.."年\n"
                    for kk,vv in pairs(v) do
                        out = out.."    "..kk.."月："
                        local nn = 0
                        for kkk,vvv in pairs(vv) do
                            nn = nn + vvv
                        end
                        out = out..nn.."次     出现日期：["

                        local daynum = {}
                        for kkk,vvv in pairs(vv) do
                            for j = 1, vvv do
                                table.insert(daynum, kkk)
                            end
                        end
                        table.sort(daynum)

                        for kkkk,vvvv in pairs(daynum) do
                            if kkkk ~= 1 then
                                out = out..","
                            end
                            out = out..vvvv
                        end
                        out = out.."]\n"
                    end
                end
            else
                out = out.."没找到这个字符串！"
            end
            dialog_config2[2].value = search_text
            dialog_config2[4].value = out
        else
            break
        end
    end
end

function statistics(subs,sel)
    local statistics_data = {} -- 从字幕行中获取的所有数据表
    local time_data = {} -- 存储出现年月日
    local prev_time = -1
    aegisub.debug.out("【所有投稿的时间和时间间隔列表】\n")
    for i = 1,#subs do
        if subs[i].class == "dialogue" and subs[i].style == "【用户视频数据表】" and subs[i].comment == false then
            local l = subs[i]
            local statist_time = -1
            if prev_time ~= -1 then
                statist_time = time_subtraction_by_day(prev_time,l.layer)
            end
            -- 获取年
            local month_tbl={}
            if time_data[l.margin_l] == nil then
                time_data[l.margin_l] = month_tbl
            end

            -- 获取月
            local day_tbl={}
            if time_data[l.margin_l][l.margin_r] == nil then
                time_data[l.margin_l][l.margin_r] = day_tbl
            end

            -- 获取日
            local day_num=1
            if time_data[l.margin_l][l.margin_r][l.margin_t] == nil then
                time_data[l.margin_l][l.margin_r][l.margin_t] = day_num
            else
                time_data[l.margin_l][l.margin_r][l.margin_t] = time_data[l.margin_l][l.margin_r][l.margin_t]+1
            end

            local sim_data = {
                ["stamp"] = l.layer,
                ["title"] = l.actor,
                ["play"] = l.effect,
                ["Y"] = l.margin_l,
                ["m"] = l.margin_r,
                ["d"] = l.margin_t,
                ["length"] = l.end_time,
                ["description"] = l.text,
                ["prev_time"] = prev_time,
            }
            table.insert(statistics_data, sim_data)
            prev_time = l.layer
            aegisub.debug.out("【投稿日期】："..l.margin_l.."."..(tostring(l.margin_r):len() == 2 and l.margin_r or "0"..l.margin_r).."."..(tostring(l.margin_t):len() == 2 and l.margin_t or "0"..l.margin_t).."    【距上次投稿天数】："..statist_time.."\n")
            
        end
    end
    aegisub.debug.out("\n\n【按月投稿数统计】\n")
    for k,v in pairs(time_data) do
        aegisub.debug.out(k.."年\n")
        for kk,vv in pairs(v) do
            aegisub.debug.out("    "..kk.."月投稿数：")
            local nn = 0
            for kkk,vvv in pairs(vv) do
                nn = nn + vvv
            end
            aegisub.debug.out(nn.."\n")
        end
    end
end

-- 输出到excel
function to_excel(subs,sel)
    local output_filename = aegisub.dialog.save("【选择音频导出位置】", "", "截取音频", "音频文件 (.xls)|*.xls", false)
    if output_filename == nil then
        aegisub.debug.out("请重新选择正确的输出位置。")
    else
        -- TODO
    end
end

TLL_macros = {
    {
		script_name = "获取up主视频基本数据",
		script_description = "根据uid获取b站up主视频的基本数据",
		entry = function(subs,sel) get_user_video_info(subs,sel) end,
		validation = false
    },
    {
		script_name = "通过搜索统计",
		script_description = "通过搜索统计",
		entry = function(subs,sel) search_on_text(subs,sel) end,
		validation = false
    },
    {
		script_name = "视频统计",
		script_description = "视频统计",
		entry = function(subs,sel) statistics(subs,sel) end,
		validation = false
    },
    -- {
	-- 	script_name = "to_excel",
	-- 	script_description = "to_excel",
	-- 	entry = function(subs,sel) to_excel(subs,sel) end,
	-- 	validation = false
    -- },
}

for i = 1, #TLL_macros do
	aegisub.register_macro(script_name.." "..script_version.."/"..TLL_macros[i]["script_name"], TLL_macros[i]["script_description"], TLL_macros[i]["entry"], TLL_macros[i]["validation"])
end