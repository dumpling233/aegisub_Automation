

local tr = aegisub.gettext
script_name = tr("一键获取tc直播历史评论")
script_description = tr("一键获取tc直播历史评论")
script_author = "拉姆0v0"
script_version = "v1.1"

include("karaskel.lua")
local request = require("luajit-request")
local util = require 'aegisub.util'
local ffi = require"ffi"
local htmlparser = require("htmlparser")
-- 序列化和反序列化方法
function serialize(obj)
    local lua = ""
    local t = type(obj)
    if t == "number" then
        lua = lua .. obj
    elseif t == "boolean" then
        lua = lua .. tostring(obj)
    elseif t == "string" then
        lua = lua .. string.format("%q", obj)
    elseif t == "table" then
        lua = lua .. "{\n"
    for k, v in pairs(obj) do
        lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
    end
    local metatable = getmetatable(obj)
        if metatable ~= nil and type(metatable.__index) == "table" then
        for k, v in pairs(metatable.__index) do
            lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
        end
    end
        lua = lua .. "}"
    elseif t == "nil" then
        return nil
    else
        error("can not serialize a " .. t .. " type.")
    end
    return lua
end

function unserialize(lua)
    local t = type(lua)
    if t == "nil" or lua == "" then
        return nil
    elseif t == "number" or t == "string" or t == "boolean" then
        lua = tostring(lua)
    else
        error("can not unserialize a " .. t .. " type.")
    end
    lua = "return " .. lua
    local func = loadstring(lua)
    if func == nil then
        return nil
    end
    return func()
end

--合并两个table
function MergeTables(...)
    local tabs = {...}
    if not tabs then
        return {}
    end
    local origin = tabs[1]
    for i = 2,#tabs do
        if origin then
            if tabs[i] then
                for k,v in pairs(tabs[i]) do
                    table.insert(origin,v)
                end
            end
        else
            origin = tabs[i]
        end
    end
    return origin
end

-- 打断获取进程
function progress_break()
    local cancelled = aegisub.progress.is_cancelled()
    if cancelled == true then
        aegisub.cancel()
    end
end

-- 获取页面接口
function get_page(url)
	local result, err, message = request.send(url)
	if (not result) then aegisub.debug.out(err, message) end
	return result.body
end

-- 根据录播链接获取评论页数
function get_pagenum(url)
    local uurl = url.."-1"
    aegisub.progress.task("正在获取评论页数...")
    local page = get_page(uurl)
    local root = htmlparser.parse(page)
    local elements = root(".tw-pager > a")
    return elements[#elements]:getcontent()
end

--获取开播时间
function get_start_time(url)
    aegisub.progress.task("正在获取开播时间...")
    local page = get_page(url)
    local root = htmlparser.parse(page)
    local elements = root(".tw-player-meta__status_item")
    local time_node_attr = elements[3].nodes[1].attributes
    local time_str = (elements[3].nodes[1]:getcontent()):match("^%s+(.-)%s+$")
    local time = ""
    for kk,vv in pairs(time_node_attr) do
        if kk == "datetime" then
            time = vv
            break
        end
    end
    return time,time_str
end

-- 获取所有页面(由于获取较慢暂时获取第一页)
function get_allcomment(url)
    aegisub.progress.task("正在获取评论页数...")
    local pagenum = get_pagenum(url.."-0")
    local comments_tbl = {}
    for i = 1, pagenum do
        aegisub.progress.task("正在获取所有页面  ("..i.."/"..pagenum..")")
        progress_break()
        local url_i = url.."-"..tonumber(i-1)
        local page = get_page(url_i)
        local root = htmlparser.parse(page)
        local elements = root(".tw-comment-history-item")
        for k,v in pairs(elements) do
            local comment_i_tbl = {}
            comment_i_tbl.text = v:select(".tw-comment-history-item__content__text")[1]:textonly():match("^%s+(.-)%s+$")
            comment_i_tbl.comment_href = v:select(".tw-comment-history-item__content__text")[1].attributes.href
            comment_i_tbl.user = v:select(".tw-comment-history-item__details__user-link")[1]:textonly():match("^%s+(.-)%s+$")
            comment_i_tbl.time = v:select(".tw-comment-history-item__info__date")[1].attributes.datetime
            comment_i_tbl.time_str = (v:select(".tw-comment-history-item__info__date")[1]:getcontent()):match("^%s+(.-)%s+$")
            table.insert(comments_tbl,comment_i_tbl)
            aegisub.progress.set(i/pagenum*100)
        end
    end
    return comments_tbl
end

-- 获取主播和直播号码
function get_steam_info(url)
    local movie_id = url:match("%d+$")
    local anchor = url:match("^https://twitcasting.tv/(.+)")
    return movie_id,anchor:match("^[^/]+")
end

-- 根据两种不同的时间格式获取时间戳
function get_stamp_from_time(time, time_str)
    local _,_,_,_,_,_,hour, min, sec = time:find("(%a+)%p%s*(%d+)%s*(%a+)%s*(%d+)%s*(%d+):(%d+):(%d+)")
    local _,_,y,m,d = time_str:find("(%d+)/(%d+)/(%d+)")
    local timestamp = os.time({year=y, month = m, day = d, hour = hour, min = min, sec = sec})
    return timestamp
end

-- 从movieurl获取评论数据
function get_comments_by_url(subs,sel,url,line_table,url_moviepage_template,url_commentpage_template)
    local movie_id,anchor = get_steam_info(url)
    local start_time, start_time_str = get_start_time(url_moviepage_template:format(anchor,movie_id))
    local start_timestamp = get_stamp_from_time(start_time, start_time_str)
    local tbl = get_allcomment(url_commentpage_template:format(anchor,movie_id))
    for i = 1,#subs do
        if subs[i].class == "dialogue" then
            for k,v in pairs(tbl) do
                local l = util.copy(line_table)
                local comment_timestamp = get_stamp_from_time(v.time, v.time_str)
                local st = comment_timestamp - start_timestamp
                l.text = v.text
                l.start_time = st*1000
                l.end_time = st*1000
                l.actor = v.user
                subs.insert(i,l)
            end
            local ll = util.copy(line_table)
            ll.comment = true
            ll.actor = "【评论发送者】"
            ll.text = "【直播开始时间】"..os.date("%Y/%m/%d %H:%M:%S", start_timestamp).." 东9区 【跳转链接】"..url_moviepage_template:format(anchor,movie_id).."【注意】可以在这里直接打开录播视频，每行的开始时间就是对应评论的发送时间。"
            subs.insert(i,ll)
            break
        end
    end
end

-- 根据链接获取历史直播页数
function get_pagenum_of_movies(url)
    local uurl = url.."0"
    aegisub.progress.task("正在获取历史直播页数...")
    local page = get_page(uurl)
    local root = htmlparser.parse(page)
    local elements = root(".paging > a")
    return elements[#elements]:getcontent()
end

-- 获取所有的历史的movie信息
function get_movies_id(url)
    aegisub.progress.task("正在获取历史直播记录...")
    local pagenum = get_pagenum_of_movies(url)
    local movies_tbl = {}
    for i = 1, pagenum do
        aegisub.progress.task("正在获取历史直播所有页面  ("..i.."/"..pagenum..")")
        progress_break()
        local url_i = url..tonumber(i-1)
        local page = get_page(url_i)
        local root = htmlparser.parse(page)
        local elements = root(".recorded-movie-box > a")
        for k,v in pairs(elements) do
            local movies_i_tbl = {}
            movies_i_tbl.title = v:select(".tw-movie-thumbnail-title")[1]:textonly():match("^%s+(.-)%s+$")
            movies_i_tbl.time = v:select(".tw-movie-thumbnail-date")[1].attributes.datetime
            movies_i_tbl.time_str = v:select(".tw-movie-thumbnail-date")[1]:getcontent()
            movies_i_tbl.movie_id = v.attributes.href:match("%d+$")
            table.insert(movies_tbl,movies_i_tbl)
        end
        aegisub.progress.set(i/pagenum*100)
    end
    return movies_tbl
end

local line_table = {
    ["layer"]=0,
    ["margin_b"]=0,
    ["class"]="dialogue",
    ["extra"]={
    },
    ["margin_t"]=0,
    ["margin_l"]=0,
    ["style"]="Default",
    ["actor"]="",
    ["start_time"]=0,
    ["raw"]="Dialogue: 0,0:00:00.00,0:00:05.00,Default,,0,0,0,,",
    ["section"]="[Events]",
    ["text"]="",
    ["margin_r"]=0,
    ["comment"]=false,
    ["effect"]="",
    ["end_time"]=5000,
}

local twitcasting_rooturl = "https://twitcasting.tv/"
local url_moviepage_template = "https://twitcasting.tv/%s/movie/%s"
local url_commentpage_template = "https://twitcasting.tv/%s/moviecomment/%s"
local url_movielist_template = "https://twitcasting.tv/%s/show/"
local tc_id = {
    "kaguramea_vov",
    "u1_8ra"
}

dialog_config1=
{
    [1]={class="label",x=0,y=0,label="【twitcasting录像地址】"},
    [2]={class="edit",name="url",x=1,y=0,width=6,height=1,items={},value=""},
    [3]={class="label",x=1,y=1,label="例如：https://twitcasting.tv/kaguramea_vov/movie/661927254"},
}

function main(subs, sel)
    local buttons1,results1 = aegisub.dialog.display(dialog_config1,{"OK","Cancel"})
    if buttons1 == "OK" then
        local url = results1["url"]
        if url:find("https://twitcasting.tv/") ~= nil then
            get_comments_by_url(subs,sel,url,line_table,url_moviepage_template,url_commentpage_template)
        else
            aegisub.debug.out("请输入正确的录播地址链接！\n例如：https://twitcasting.tv/kaguramea_vov/movie/661927254")
        end
    else
        aegisub.debug.out("已取消！")
    end
end

dialog_config_user=
{
    [1]={class="label",x=0,y=0,label="【输入用户id】"},
    [2]={class="edit",name="seleted_user",x=1,y=0,width=6,height=1,items={},value="kaguramea_vov"},
}

dialog_config_movies=
{
    [1]={class="label",x=0,y=0,label="【选择历史直播】"},
    [2]={class="dropdown",name="seleted_movie",x=1,y=0,width=20,height=1,items={},value=""},
}

function main2(subs, sel)
    local buttons1,results1 = aegisub.dialog.display(dialog_config_user,{"OK","Cancel"})
    if buttons1 == "OK" then
        local user_id = results1["seleted_user"]
        local movies_tbl = get_movies_id(url_movielist_template:format(user_id))
        local dialog_seleted_movie_tbl = {}
        for k,v in pairs(movies_tbl) do
            table.insert(dialog_seleted_movie_tbl, "【时间】东9区"..os.date("%Y/%m/%d %H:%M:%S", get_stamp_from_time(v.time, v.time_str)).."【录播id】"..v.movie_id)
        end
        dialog_config_movies[2].items = dialog_seleted_movie_tbl
        local buttons2,results2 = aegisub.dialog.display(dialog_config_movies,{"OK","Cancel"})
        if buttons2 == "OK" then
            local movie_id = results2["seleted_movie"]
            local url = url_moviepage_template:format(user_id,movie_id:match("%d+$"))
            get_comments_by_url(subs,sel,url,line_table,url_moviepage_template,url_commentpage_template)
        else
            aegisub.debug.out("已取消！")
        end
    else
        aegisub.debug.out("已取消！")
    end
    -- local tbl = get_movies_id(url_movielist_template:format("kaguramea_vov"))
    -- aegisub.debug.out(serialize(tbl))
end


TLL_macros = {
    {
		script_name = "一键获取tc直播历史评论 v1.0",
		script_description = "一键获取tc直播历史评论",
		entry = function(subs,sel) main(subs,sel) end,
		validation = false
    },
    {
		script_name = "查询tc主播 v1.1",
		script_description = "test2",
		entry = function(subs,sel) main2(subs,sel) end,
		validation = false
    }
}

for i = 1, #TLL_macros do
	aegisub.register_macro(script_name.." "..script_version.."/"..TLL_macros[i]["script_name"], TLL_macros[i]["script_description"], TLL_macros[i]["entry"], TLL_macros[i]["validation"])
end