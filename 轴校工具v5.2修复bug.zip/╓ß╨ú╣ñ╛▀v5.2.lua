local tr = aegisub.gettext
script_name = tr("轴校工具")
script_description = tr("脱裤子放屁工具")
script_author = "拉姆0v0"
script_version = "v5.1"

dialog_config1=
{

	[1]={class="label",x=0,y=0,label="对齐设置："},
	[2]={class="label",x=0,y=1,label="【设置闪轴最短时长】(单位ms)—————————————————————————————————————>>"},
	[3]={class="intedit",name="时间间隔",x=1,y=1,width=1,height=1,items={},value=300,hint="请输入整数"},
	[4]={class="label",x=0,y=3,label="【设置对齐检测时长】(单位ms)—————————————————————————————————————>>"},
	[5]={class="intedit",name="最短时间",x=1,y=3,width=1,height=1,items={},value=100,hint="请输入整数"},
	[6]={class="label",x=0,y=2,label="说明：若对齐后轴间时长小于闪轴最短时长则不会对齐"},
	[7]={class="label",x=0,y=4,label="说明：不同样式之间的开始时间或结束时间之差小于该时长时，在保证对齐后的轴不会出现闪轴的情况之下，进行延长对齐"},
}

function text_processing1(subs)
	buttons,results =aegisub.dialog.display(dialog_config1,{"OK","Cancel"})
	if buttons=="OK" then
		local timex = results["时间间隔"]
		local timey = results["最短时间"]
		local stylen={}
		local stylenline={}
		local changestartnum=0
		local changeendnum=0
		for i=1,#subs do
			if subs[i].class == "dialogue" and subs[i].comment == false then
				if #stylen == 0 then
					table.insert(stylen,subs[i].style)
					table.insert(stylenline,{i})
				else
					local isin=0
					for j=1,#stylen do
						if subs[i].style == stylen[j] then
							table.insert(stylenline[j],i)
							isin=1
							break
						end
					end
					if isin==0 then
						table.insert(stylen,subs[i].style)
						table.insert(stylenline,{i})
					end
				end
			end
		end
		-- 测试
		for i=1,#stylen do
		    for j=1,#stylenline[i] do
				for k=1,#stylen do
					if k ~= i then
						for l=1,#stylenline[k] do
							-- 检测头
							if subs[stylenline[k][l]].start_time - subs[stylenline[i][j]].start_time  < timey and subs[stylenline[k][l]].start_time - subs[stylenline[i][j]].start_time  > 0 then
								if l ~= 1 and (subs[stylenline[i][j]].start_time - subs[stylenline[k][l-1]].end_time > timex) then
									local subp = subs[stylenline[k][l]]
									subp.start_time = subs[stylenline[i][j]].start_time
									subp.actor = "【开始时间提前了"..(subs[stylenline[k][l]].start_time - subs[stylenline[i][j]].start_time).."毫秒】"..subp.actor
									subs[stylenline[k][l]] = subp
									changestartnum = changestartnum + 1 
								end
								if l == 1 then
									local subp = subs[stylenline[k][l]]
									subp.start_time = subs[stylenline[i][j]].start_time
									subp.actor = "【开始时间提前了"..(subs[stylenline[k][l]].start_time - subs[stylenline[i][j]].start_time).."毫秒】"..subp.actor
									subs[stylenline[k][l]] = subp
									changestartnum = changestartnum + 1

								end

							end
							-- 检测尾
							if subs[stylenline[i][j]].end_time - subs[stylenline[k][l]].end_time  < timey and subs[stylenline[i][j]].end_time - subs[stylenline[k][l]].end_time  > 0 then
								if l ~= #stylenline[k] and (subs[stylenline[k][l+1]].start_time - subs[stylenline[i][j]].end_time  > timex) then
									local subp = subs[stylenline[k][l]]
									subp.end_time = subs[stylenline[i][j]].end_time
									subp.actor = "【结束时间延后了"..(subs[stylenline[i][j]].end_time - subs[stylenline[k][l]].end_time).."毫秒】"..subp.actor
									subs[stylenline[k][l]] = subp
									changeendnum = changeendnum + 1 
								end
								if l == #stylenline[k] then
									local subp = subs[stylenline[k][l]]
									subp.end_time = subs[stylenline[i][j]].end_time
									subp.actor = "【结束时间延后了"..(subs[stylenline[i][j]].end_time - subs[stylenline[k][l]].end_time).."毫秒】"..subp.actor
									subs[stylenline[k][l]] = subp
									changeendnum = changeendnum + 1 
								end
							end
						end
					end 
					-- subs[stylenline[i][j+1]]
				end
			end
		end
		aegisub.debug.out("修改开始时间"..changestartnum.."处\n")
		aegisub.debug.out("修改结束时间"..changeendnum.."处\n\n")
		aegisub.debug.out("如想撤销，可ctrl+z撤回操作")
		aegisub.debug.out("\n修改情况或修改建议已标记在相应行的说话人一栏，请查看。              ————by 拉姆0v0")
	end
end

-- 功能二
dialog_config2=
{

	[1]={class="label",x=0,y=0,label="替换项目设置："},
	[2]={class="label",x=0,y=1,label="删除句首句末空格"},
	[3]={class="label",x=0,y=2,label="删除句末句号"},
	[4]={class="label",x=0,y=3,label="替换句中逗号为半角空格"},
    [5]={class="checkbox",x=1,y=1,name = "delete_startendspace", value = true},
	[6]={class="checkbox",x=1,y=2,name = "delete_stop", value = true},
	[7]={class="checkbox",x=1,y=3,name = "commatospace", value = true},
}

function delete_startendspace(subs)
	for i = 1, #subs do
		if subs[i].class == "dialogue" and subs[i].comment == false then
			local subp = subs[i]
			-- 
			-- subp.text = string.gsub(subp.text, "^　+", "")
			-- 
			-- subp.text = string.gsub(subp.text, "　+$", "")
			subp.text = string.gsub(subp.text, "　", " ")
			subp.text = string.gsub(subp.text, "^ +", "")
			subp.text = string.gsub(subp.text, " +$", "")

			subs[i] = subp
		end
	end
end

function delete_stop(subs)
	for i = 1, #subs do
		if subs[i].class == "dialogue" and subs[i].comment == false then
			local subp = subs[i]
			subp.text = string.gsub(subp.text, "。$", "")
			subs[i] = subp
		end
	end
end

function commatospace(subs)
	for i = 1, #subs do
		if subs[i].class == "dialogue" and subs[i].comment == false then
			local subp = subs[i]
			subp.text = string.gsub(subp.text, ",", " ")
			subp.text = string.gsub(subp.text, "，", " ")
			subs[i] = subp
		end
	end
end

function all_processing(subs)
	buttons,results =aegisub.dialog.display(dialog_config2,{"OK","Cancel"})
	if buttons == "OK" then
		if results["delete_startendspace"] == true then
			delete_startendspace(subs)
		end
		if results["delete_stop"] == true then
			delete_stop(subs)
		end
		if results["commatospace"] == true then
			commatospace(subs)
		end
	end
	
end

-- 功能三
dialog_config3=
{

	[1]={class="label",x=0,y=0,label="检测项目设置"},
	[2]={class="label",x=0,y=1,label="【闪轴检测设置】设置要检查的前后之间的时间间隔(单位ms)："},
	[3]={class="intedit",name="时间间隔",x=1,y=1,width=1,height=1,items={},value=300,hint="请输入整数"},
	[4]={class="label",x=0,y=2,label="【过短轴检测设置】设置要检查的单行轴的最短时长(单位ms)："},
	[5]={class="intedit",name="时间长度",x=1,y=2,width=1,height=1,items={},value=500,hint="请输入整数"},
	[6]={class="label",x=0,y=3,label="【文本长度检测】单行最大字符数："},
	[7]={class="intedit",name="单行最大字符数",x=1,y=3,width=1,height=1,items={},value=22,hint="请输入整数"},
--	[8]={class="label",x=0,y=3,label="【文本长度检测2】单行字幕最大宽度(结合样式)："},
--	[9]={class="intedit",name="单行最大宽度",x=1,y=2,width=1,height=1,items={},value=1280,hint="请输入整数"},
}



--function getstyletable(subs,stylename)
--	local isalive=0
--	local styletable
--	for i=1,#subs do
--		if subs[i].section=="[V4+ Styles]" and subs[i].name==stylename then
--			isalive=1
--			styletable=subs[i]
--		end
--	end
--	if isalive==1 then
--		return styletable
--	else
--		return nil
--	end
--end

--function checktextwidth_byconcreetwidth(subs,subp,limitwidth)
--	local styletable=getstyletable(subs,subp.style)
--	if styletable~=nil then
--		local width, height, descent, ext_lead =aegisub.text_extents(styletable,subp.text)
--		local check=1
--		if width > limitwidth then
--			check=2
--		end
--	else
--		check=1
--	end
--	return check
--end

function getStringLength(inputstr)
    if not inputstr or type(inputstr) ~= "string" or #inputstr <= 0 then
        return nil
    end
    local length = 0  -- 字符的个数
    local i = 1
    while true do
        local curByte = string.byte(inputstr, i)
        local byteCount = 1
        if curByte > 239 then
            byteCount = 4  -- 4字节字符
        elseif curByte > 223 then
            byteCount = 3  -- 汉字
        elseif curByte > 128 then
            byteCount = 2  -- 双字节字符
        else
            byteCount = 1  -- 单字节字符
        end
        i = i + byteCount
        length = length + 1
        if i > #inputstr then
            break
        end
    end
    return length
end

function text_processing3(subs,sel)
	buttons,results =aegisub.dialog.display(dialog_config3,{"OK","Cancel"})
	if buttons=="OK" then
		local timex = results["时间间隔"]
		local timey = results["时间长度"]
		local stylen={}
		local stylenline={}
		local shannum={}
		local dienum={}
		local guoduannum={}
		local allnum={0,0,0}

		local limitnum=results["单行最大字符数"]
		local limit=0
		for i=1,#subs do
			if subs[i].class == "dialogue" and subs[i].comment == false then
				if #stylen == 0 then
					table.insert(stylen,subs[i].style)
					table.insert(shannum,0)
					table.insert(dienum,0)
					table.insert(guoduannum,0)
					table.insert(stylenline,{i})
				else
					local isin=0
					for j=1,#stylen do
						if subs[i].style == stylen[j] then
							table.insert(stylenline[j],i)
							isin=1
							break
						end
					end
					if isin==0 then
						table.insert(stylen,subs[i].style)
						table.insert(shannum,0)
						table.insert(dienum,0)
						table.insert(guoduannum,0)
						table.insert(stylenline,{i})
					end
				end
			end
		end
--查找闪轴部分
        aegisub.debug.out("检查内容：\n【闪轴】各样式内部检查，前后间隔小于"..tostring(timex).."毫秒的情况。\n【叠轴】各样式内部检查，前后行存在重叠的情况。\n【过短轴】单行时间小于"..tostring(timey).."毫秒的情况。\n【文本偏长】文本字符数大于"..tostring(limitnum).."的情况。(任何字符都计算为1，包括空格)\n\n在不同样式中的情况：\n")
	    for i=1,#stylen do
		    aegisub.debug.out("【"..stylen[i].."】：")
		    for j=1,(#stylenline[i]-1) do
			    if (subs[stylenline[i][j+1]].start_time-subs[stylenline[i][j]].end_time <= timex) and (subs[stylenline[i][j+1]].start_time-subs[stylenline[i][j]].end_time > 0) then
			    	local subp = subs[stylenline[i][j]]
		        	subp.actor = "(【闪轴】该样式中的此行与下一行之间的间隔小于"..tostring(timex).."毫秒，请调整)"..subp.actor
					subs[stylenline[i][j]] = subp


					shannum[i]=shannum[i]+1
					allnum[1]=allnum[1]+1
				end

				if subs[stylenline[i][j+1]].start_time < subs[stylenline[i][j]].end_time then
			    	local subp = subs[stylenline[i][j]]
		        	subp.actor = "(【叠轴】该样式中的此行与下一行存在重叠，请调整)"..subp.actor
					subs[stylenline[i][j]] = subp


					dienum[i]=dienum[i]+1
					allnum[2]=allnum[2]+1
				end

			end
			for k=1,#stylenline[i] do
				if subs[stylenline[i][k]].end_time-subs[stylenline[i][k]].start_time <= timey then
			    	local subp = subs[stylenline[i][k]]
		        	subp.actor = "(【过短轴】这行轴时长过短，小于"..tostring(timey).."毫秒，请调整)"..subp.actor
					subs[stylenline[i][k]] = subp


					guoduannum[i]=guoduannum[i]+1
					allnum[3]=allnum[3]+1

				end
			end
			aegisub.debug.out("闪轴"..tostring(shannum[i]).."处  ||  叠轴"..tostring(dienum[i]).."处  ||  过短轴"..tostring(guoduannum[i]).."处\n")
		end
		
		for i=1,#subs do
			
			if subs[i].class == "dialogue" and subs[i].comment == false and getStringLength(subs[i].text) > limitnum then
				local subp = subs[i]
				subp.actor = "(【文本偏长提示】这行轴的文本字符数大于"..tostring(limitnum)..")"..subp.actor
				subs[i] = subp
				limit=limit+1
			end
		end
		aegisub.debug.out("\n总体情况：闪轴"..tostring(allnum[1]).."处  ||  叠轴"..tostring(allnum[2]).."处  ||  过短轴"..tostring(allnum[3]).."处  ||  文本偏长"..tostring(limit).."处\n\n如想撤销，可ctrl+z撤回操作\n修改情况或修改建议已标记在相应行的说话人一栏，请查看。              ————by 拉姆0v0")

	end
end


-- 功能四 检测间隔过长
dialog_config4=
{

	[1]={class="label",x=0,y=0,label="【设置检测最长时间间隔】大于此时长的时间间隔会被标记(单位ms)"},
	[2]={class="intedit",name="最长时间间隔",x=1,y=0,width=1,height=1,items={},value=5000,hint="请输入整数"},
}

function text_processing4(subs)
	buttons,results =aegisub.dialog.display(dialog_config4,{"OK","Cancel"})
	if buttons == "OK" then
		local timexy = results["最长时间间隔"]
		local timenum = 0
		for i = 1, (#subs-1) do
			if subs[i].class == "dialogue" and subs[i].comment == false then
				if subs[i+1].start_time - subs[i].end_time >= timexy then
					timenum = timenum + 1
					local subp = subs[i]
		        	subp.actor = "(【间隔过长】该行与下行之间的间隔大于等于"..tostring(timexy).."毫秒)"..subp.actor
					subs[i] = subp
				end
			end
		end
		aegisub.debug.out("共有【"..timenum.."】处轴间间隔过长，位置已标记在间隔前一行的说话人一栏。")
	end
	
end

TLL_macros = {
	{
		script_name = "多人轴对齐修正微调 v1.0",
		script_description = "多人轴对齐",
		entry = function(subs,sel) text_processing1(subs,sel) end,
		validation = false
	},
	{
		script_name = "替换不规范字符 v1.0",
		script_description = "替换不规范字符",
		entry = function(subs,sel) all_processing(subs,sel) end,
		validation = false
	},
	{
		script_name = "检查闪轴、过短轴、叠轴以及文本过长(适用于多人轴) v5.0",
		script_description = "检查不规范情况",
		entry = function(subs,sel) text_processing3(subs,sel) end,
		validation = false
	},
	{
		script_name = "间隔过长检测",
		script_description = "检测剪辑是否恰当",
		entry = function(subs,sel) text_processing4(subs,sel) end,
		validation = false
	},
	
}

for i = 1, #TLL_macros do
	aegisub.register_macro(script_name.." "..script_version.."/"..TLL_macros[i]["script_name"], TLL_macros[i]["script_description"], TLL_macros[i]["entry"], TLL_macros[i]["validation"])
end
