-- 功能：
--     将只有path路径的svg绘图转化为bas弹幕格式，或者是assdraw支持的绘图格式。
-- 注意：
--     仅支持只有path路径的复杂svg绘图。不支持带有普通矢量简单图形标签的svg绘图。
--     并且仅支持带有m l c h v z q以及它们的大写字母的path路径的转化。
-- 更新：
--     20.12.24 
--       1.增加了对路径中小数的支持。
--       2.增加了对path中Q和q两个二次贝塞尔曲线command的解析。
--     20.12.28
--       1.增加了对空g节点的判断，防止空节点导致的报错问题。



local tr = aegisub.gettext
script_name = tr("svg解析")
script_description = tr("svg解析")
script_author = "拉姆0v0"
script_version = "v1.2"

-- 序列化和反序列化方法
function serialize(obj)
    local lua = ""
    local t = type(obj)
    if t == "number" then
        lua = lua .. obj
    elseif t == "boolean" then
        lua = lua .. tostring(obj)
    elseif t == "string" then
        lua = lua .. string.format("%q", obj)
    elseif t == "table" then
        lua = lua .. "{\n"
    for k, v in pairs(obj) do
        lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
    end
    local metatable = getmetatable(obj)
        if metatable ~= nil and type(metatable.__index) == "table" then
        for k, v in pairs(metatable.__index) do
            lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"
        end
    end
        lua = lua .. "}"
    elseif t == "nil" then
        return nil
    else
        error("can not serialize a " .. t .. " type.")
    end
    return lua
end

function unserialize(lua)
    local t = type(lua)
    if t == "nil" or lua == "" then
        return nil
    elseif t == "number" or t == "string" or t == "boolean" then
        lua = tostring(lua)
    else
        error("can not unserialize a " .. t .. " type.")
    end
    lua = "return " .. lua
    local func = loadstring(lua)
    if func == nil then
        return nil
    end
    return func()
end


-- 逗号转空格
function commaToSpace(path)
    return string.gsub(path, ",", " ")
end

-- 字母空格处理
function spaceProcessing(path)
    local pathSimple = ""
    for word in string.gmatch(path, "[%a][%A]*") do 
        pathSimple = pathSimple..string.sub(word, 1, 1).." "..string.sub(word, 2).." "
    end
    pathSimple = string.gsub(pathSimple, "[%s]+", " ")
    return pathSimple
end


-- path转table
function cutPathToTable(path)
    local pathSimpleTable = {}
    for word in string.gmatch(path, "[%a][%A]*") do 
        table.insert(pathSimpleTable, word)
    end
    return pathSimpleTable
end

-- path路径相对路径全部转为绝对路径
function pathTableToAbsolute(pathTable)
    local anchorStr = pathTable[1]:match( "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+")
    local anchorX = tonumber(anchorStr:sub(1,anchorStr:find("[%s]+")-1))
    local anchorY = tonumber(anchorStr:sub(anchorStr:find("[%s]+")+1,-1))
    local startFlag = true
    -- 每个独立绘图中的开始点记录
    local simpleAnchorX = anchorX
    local simpleAnchorY = anchorY
    for k,v in pairs(pathTable) do
        local head = v:sub(1, 1)

        -- 处理m
        if head == "m" then
            local replaceStr = "M "
            -- 判断循环次数,用于处理存储独立绘图的开始点
            local isFirst = true
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                if startFlag then
                    startFlag = false
                    replaceStr = replaceStr..tostring(anchorX).." "..tostring(anchorY).." "
                else
                    anchorX = anchorX + tonumber(word:sub(1,word:find("[%s]+")-1))
                    anchorY = anchorY + tonumber(word:sub(word:find("[%s]+")+1,-1))
                    replaceStr = replaceStr..tostring(anchorX).." "..tostring(anchorY).." "
                end
                if isFirst then
                    simpleAnchorX = anchorX
                    simpleAnchorY = anchorY
                    isFirst = false
                end
            end
            pathTable[k] = replaceStr
        end
        if head == "M" then
            startFlag = false
            -- 判断循环次数,用于处理存储独立绘图的开始点
            local isFirst = true
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = tonumber(word:sub(word:find("[%s]+")+1,-1))
                if isFirst then
                    simpleAnchorX = anchorX
                    simpleAnchorY = anchorY
                    isFirst = false
                end
            end
        end

        -- 处理z
        if head == "Z" or head == "z" then
            anchorX = simpleAnchorX
            anchorY = simpleAnchorY
            pathTable[k] = " "
        end
        
        -- 处理l
        if head == "l" then
            local replaceStr = "L "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = anchorX + tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = anchorY + tonumber(word:sub(word:find("[%s]+")+1,-1))
                replaceStr = replaceStr..tostring(anchorX).." "..tostring(anchorY).." "
            end
            pathTable[k] = replaceStr
        end
        if head == "L" then
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = tonumber(word:sub(word:find("[%s]+")+1,-1))
            end
        end

        -- 处理h
        if head == "h" then
            local middleStr = "l "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+") do 
                middleStr = middleStr..word.." 0 "
            end
            local replaceStr = "L "
            for word in string.gmatch(middleStr, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = anchorX + tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = anchorY + tonumber(word:sub(word:find("[%s]+")+1,-1))
                replaceStr = replaceStr..tostring(anchorX).." "..tostring(anchorY).." "
            end
            pathTable[k] = replaceStr
        end
        if head == "H" then
            local replaceStr = "L "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+") do 
                replaceStr = replaceStr..word.." "..anchorY.." "
            end
            pathTable[k] = replaceStr
            for word in string.gmatch(replaceStr, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = tonumber(word:sub(word:find("[%s]+")+1,-1))
            end
        end

        -- 处理v
        if head == "v" then
            local middleStr = "l "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+") do 
                middleStr = middleStr.."0 "..word.." "
            end
            local replaceStr = "L "
            for word in string.gmatch(middleStr, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = anchorX + tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = anchorY + tonumber(word:sub(word:find("[%s]+")+1,-1))
                replaceStr = replaceStr..tostring(anchorX).." "..tostring(anchorY).." "
            end
            pathTable[k] = replaceStr
        end
        if head == "V" then
            local replaceStr = "L "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+") do 
                replaceStr = replaceStr..anchorX.." "..word.." "
            end
            pathTable[k] = replaceStr
            for word in string.gmatch(replaceStr, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = tonumber(word:sub(word:find("[%s]+")+1,-1))
            end
        end

        -- 处理c
        if head == "c" then
            local replaceStr = "C "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                local matchTime = 1
                for word_b in string.gmatch(word, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do
                    local x = anchorX + tonumber(word_b:sub(1,word_b:find("[%s]+")-1))
                    local y = anchorY + tonumber(word_b:sub(word_b:find("[%s]+")+1,-1))
                    replaceStr = replaceStr..tostring(x).." "..tostring(y).." "
                    if matchTime == 3 then
                        anchorX = x
                        anchorY = y
                    end
                    matchTime = matchTime+1
                end
            end
            pathTable[k] = replaceStr
        end
        if head == "C" then
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                anchorX = tonumber(word:sub(1,word:find("[%s]+")-1))
                anchorY = tonumber(word:sub(word:find("[%s]+")+1,-1))
            end
        end

        -- 处理q
        if head == "q" then
            local replaceStr = "C "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do
                local matchTime = 1
                local Qcx
                local Qcy
                for word_b in string.gmatch(word, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do
                    if matchTime == 1 then
                        Qcx = anchorX + tonumber(word_b:sub(1,word_b:find("[%s]+")-1))
                        Qcy = anchorY + tonumber(word_b:sub(word_b:find("[%s]+")+1,-1))
                        local cx1 = anchorX*(1/3) + Qcx*(2/3)
                        local cy1 = anchorY*(1/3) + Qcy*(2/3)
                        replaceStr = replaceStr..tostring(cx1).." "..tostring(cy1).." "
                    elseif matchTime == 2 then
                        anchorX = anchorX + tonumber(word_b:sub(1,word_b:find("[%s]+")-1))
                        anchorY = anchorY + tonumber(word_b:sub(word_b:find("[%s]+")+1,-1))
                        local cx2 = anchorX*(1/3) + Qcx*(2/3)
                        local cy2 = anchorY*(1/3) + Qcy*(2/3)
                        replaceStr = replaceStr..tostring(cx2).." "..tostring(cy2).." "
                        replaceStr = replaceStr..tostring(anchorX).." "..tostring(anchorY).." "
                    end
                    matchTime = matchTime+1
                end
            end
            pathTable[k] = replaceStr
        end
        if head == "Q" then
            local replaceStr = "C "
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do
                local matchTime = 1
                local Qcx
                local Qcy
                for word_b in string.gmatch(word, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do
                    if matchTime == 1 then
                        Qcx = tonumber(word_b:sub(1,word_b:find("[%s]+")-1))
                        Qcy = tonumber(word_b:sub(word_b:find("[%s]+")+1,-1))
                        local cx1 = anchorX*(1/3) + Qcx*(2/3)
                        local cy1 = anchorY*(1/3) + Qcy*(2/3)
                        replaceStr = replaceStr..tostring(cx1).." "..tostring(cy1).." "
                    elseif matchTime == 2 then
                        anchorX = tonumber(word_b:sub(1,word_b:find("[%s]+")-1))
                        anchorY = tonumber(word_b:sub(word_b:find("[%s]+")+1,-1))
                        local cx2 = anchorX*(1/3) + Qcx*(2/3)
                        local cy2 = anchorY*(1/3) + Qcy*(2/3)
                        replaceStr = replaceStr..tostring(cx2).." "..tostring(cy2).." "
                        replaceStr = replaceStr..tostring(anchorX).." "..tostring(anchorY).." "
                    end
                    matchTime = matchTime+1
                end
            end
            pathTable[k] = replaceStr
        end

    end
    return pathTable
end

-- 补足绘图代码
function makeUpPathTable(pathTable)
    for k,v in pairs(pathTable) do
        local head = v:sub(1, 1)
        if head == "M" then
            local replaceStr = "M "
            local isFirst = true
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                if isFirst then
                    replaceStr = replaceStr..word.." "
                    isFirst = false
                else
                    replaceStr = replaceStr.."L "..word.." "
                end
            end
            pathTable[k] = replaceStr
        end
        if head == "L" then
            local replaceStr = "L "
            local isFirst = true
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                if isFirst then
                    replaceStr = replaceStr..word.." "
                    isFirst = false
                else
                    replaceStr = replaceStr.."L "..word.." "
                end
            end
            pathTable[k] = replaceStr
        end
        if head == "C" then
            local replaceStr = "B "
            local isFirst = true
            for word in string.gmatch(v, "[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+[%s]+[%-?%d+%.*%d*]+") do 
                if isFirst then
                    replaceStr = replaceStr..word.." "
                    isFirst = false
                else
                    replaceStr = replaceStr.."B "..word.." "
                end
            end
            pathTable[k] = replaceStr
        end
    end
    return pathTable
end

-- 路径处理
function pathProcessing(path)
    local pathTable = makeUpPathTable(pathTableToAbsolute(cutPathToTable(spaceProcessing(commaToSpace(path)))))
    local out = ""
    for k,v in pairs(pathTable) do
        out = out..v
    end
    return string.lower(out)
end

function RGBtoBGR(color)
    local length = #color
    local B = color:sub(length-1, length)
    local G = color:sub(length-3, length-2)
    local R = color:sub(length-5, length-4)
    return "H"..B..G..R
end

-- bas输出模板
local basSvgTemplate = "def path p(d = \"m\", fillColor = 0x00a1d6, viewBox = \"0 0 7070 8030\"){\n"
basSvgTemplate = basSvgTemplate.."    d = d\n"
basSvgTemplate = basSvgTemplate.."    viewBox=viewBox\n"
basSvgTemplate = basSvgTemplate.."    x = 0%\n"
basSvgTemplate = basSvgTemplate.."    y = 0%\n"
basSvgTemplate = basSvgTemplate.."    height = 100%\n"
basSvgTemplate = basSvgTemplate.."    duration = 12s\n"
basSvgTemplate = basSvgTemplate.."    borderWidth = 0\n"
basSvgTemplate = basSvgTemplate.."    borderColor = 0x000000\n"
basSvgTemplate = basSvgTemplate.."    borderAlpha = 0\n"
basSvgTemplate = basSvgTemplate.."    fillColor = fillColor\n"
basSvgTemplate = basSvgTemplate.."    fillAlpha = 1\n"
basSvgTemplate = basSvgTemplate.."}\n"

local basSvgExample = "let p%s = p (\"%s\", %s, \"%s\")\n"

-- xml格式解析方法
function htmlParser(xmlString)
    local xml = require("xmlSimple").newParser()
    local xmlTab = xml:ParseXmlText(xmlString)
    local viewBox = xmlTab.svg["@viewBox"]
    local pathTable = {}
    if xmlTab.svg.g["@fill"] == nil then
        for k,v in pairs(xmlTab.svg.g) do
            if v.path ~= nil then
                if v.path["@d"] ~= nil then
                    local pathTableSimple = {}
                    pathTableSimple.color = v["@fill"]
                    pathTableSimple.path = v.path["@d"]
                    table.insert(pathTable, pathTableSimple)
                else
                    for kk,vv in pairs(v.path) do
                        local pathTableSimple = {}
                        pathTableSimple.color = v["@fill"]
                        pathTableSimple.path = vv["@d"]
                        table.insert(pathTable, pathTableSimple)
                    end
                end
            end
        end
    else
        if xmlTab.svg.g.path ~= nil then
            if xmlTab.svg.g.path["@d"] ~= nil then
                local pathTableSimple = {}
                pathTableSimple.color = xmlTab.svg.g["@fill"]
                pathTableSimple.path = xmlTab.svg.g.path["@d"]
                table.insert(pathTable, pathTableSimple)
            else
                for kkk,vvv in pairs(xmlTab.svg.g.path) do
                    local pathTableSimple = {}
                    pathTableSimple.color = xmlTab.svg.g["@fill"]
                    pathTableSimple.path = vvv["@d"]
                    table.insert(pathTable, pathTableSimple)
                end
            end
        end
    end
    return viewBox,pathTable
end


-- 主函数
function svg2bas(subs,sel)
    filename = aegisub.dialog.open('请选择一张svg图片', '', '','svg文件 (.svg)|*.svg', false, true)
    if filename ~= nil then
        f = io.open(filename,'r')
        local s = f:read("*a")
        f:close()
    
        output_filename = aegisub.dialog.save("请选择bas代码导出位置", "", "bas代码", "文本文档 (.txt)|*.txt", false)
        if output_filename ~= nil then
            funs=io.open(output_filename,"w+")
            funs:write(basSvgTemplate)
            local viewBox,pathTable = htmlParser(s)
            for k,v in pairs(pathTable) do
                
                local example = string.format(basSvgExample,k,v.path,string.gsub(v.color,"#","0x"),viewBox)
                funs:write(example)
            end
            funs:close()
        else
            aegisub.debug.out("请选择导出存储位置。")
        end
    else
        aegisub.debug.out("请选择一张svg格式的图片。")
    end
    
end

function svg2ass(subs,sel)
    filename = aegisub.dialog.open('请选择一张svg图片', '', '','svg文件 (.svg)|*.svg', false, true)
    if filename ~= nil then
        f = io.open(filename,'r')
        local s = f:read("*a")
        f:close()
    
        local viewBox,pathTable = htmlParser(s)
        -- 所有的绘图数据
        local assTable = {}
        for k,v in pairs(pathTable) do
            local assTable_a = {color = RGBtoBGR(v.color), pic = pathProcessing(v.path)}
            table.insert(assTable, assTable_a)
        end
    
        -- 行表
        local codeLineTable = {
            ["layer"]=0,
            ["margin_b"]=0,
            ["class"]="dialogue",
            ["extra"]={
            },
            ["margin_t"]=0,
            ["margin_l"]=0,
            ["style"]="Default",
            ["actor"]="",
            ["start_time"]=0,
            ["raw"]="Comment: 0,0:00:00.00,0:00:05.00,Default,,0,0,0,code once,pic_table="..serialize(assTable),
            ["section"]="[Events]",
            ["text"]="pic_table="..serialize(assTable),
            ["margin_r"]=0,
            ["comment"]=true,
            ["effect"]="code once",
            ["end_time"]=5000,
        }
        local templateLineTable = {
            ["layer"]=0,
            ["margin_b"]=0,
            ["class"]="dialogue",
            ["extra"]={
            },
            ["margin_t"]=0,
            ["margin_l"]=0,
            ["style"]="Default",
            ["actor"]="",
            ["start_time"]=5000,
            ["raw"]="Comment: 0,0:00:05.00,0:00:07.00,Default,,0,0,0,template syl notext noblank,!maxloop(#pic_table)!{\\an7\\shad0\\bord0\\1c&!pic_table[j].color!&\\fsc100\\pos(0,0)\\p1}!pic_table[j].pic!",
            ["section"]="[Events]",
            ["text"]="!maxloop(#pic_table)!{\\an7\\shad0\\bord0\\1c&!pic_table[j].color!&\\fsc100\\pos(0,0)\\p1}!pic_table[j].pic!",
            ["margin_r"]=0,
            ["comment"]=true,
            ["effect"]="template syl notext noblank",
            ["end_time"]=7000,
        }
        local k_lineTable = {
            ["layer"]=0,
            ["margin_b"]=0,
            ["class"]="dialogue",
            ["extra"]={
            },
            ["margin_t"]=0,
            ["margin_l"]=0,
            ["style"]="Default",
            ["actor"]="",
            ["start_time"]=7000,
            ["raw"]="Comment: 0,0:00:07.00,0:00:09.00,Default,,0,0,0,karaoke,{\\k1}1",
            ["section"]="[Events]",
            ["text"]="{\\k1}1",
            ["margin_r"]=0,
            ["comment"]=true,
            ["effect"]="karaoke",
            ["end_time"]=9000,
        }
        for i=1,#subs do
            if subs[i].class == "dialogue" then
                subs.insert(i,k_lineTable)
                subs.insert(i,templateLineTable)
                subs.insert(i,codeLineTable)
                break
            end
        end
    else
        aegisub.debug.out("请选择一张svg格式的图片。")
    end
    
end

-- 测试用内容

dialog_config=
{
    [1]={class="textbox",name="path",x=0,y=0,width=35,height=14,items={},value=""},
    [2]={class="textbox",name="out",x=35,y=0,width=35,height=14,items={},value=""},
}


function test2(subs,sel)
    buttons = "OK"
    while buttons=="OK" do
        buttons,results =aegisub.dialog.display(dialog_config,{"OK","Cancel"})
        local pathTest = results["path"]
        local toTable = cutPathToTable(spaceProcessing(commaToSpace(pathTest)))
        local out = ""
        for k,v in pairs(makeUpPathTable(pathTableToAbsolute(toTable))) do
            out = out..v
        end
        dialog_config[1].value = pathTest
        dialog_config[2].value = pathProcessing(pathTest)
    end
end

TLL_macros = {
	{
		script_name = "svg2bas",
		script_description = "svg2bas",
		entry = function(subs,sel) svg2bas(subs,sel) end,
		validation = false
    },
    {
		script_name = "svg2ass",
		script_description = "svg2ass",
		entry = function(subs,sel) svg2ass(subs,sel) end,
		validation = false
	},
    -- {
	-- 	script_name = "测试",
	-- 	script_description = "测试",
	-- 	entry = function(subs,sel) test2(subs,sel) end,
	-- 	validation = false
	-- }
}

for i = 1, #TLL_macros do
	aegisub.register_macro(script_name.." "..script_version.."/"..TLL_macros[i]["script_name"], TLL_macros[i]["script_description"], TLL_macros[i]["entry"], TLL_macros[i]["validation"])
end